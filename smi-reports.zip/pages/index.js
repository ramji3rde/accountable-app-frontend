import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/router'
import { BsEye, BsEyeSlash } from 'react-icons/bs'
import { IoChevronForwardOutline } from "react-icons/io5";
import { useFormik } from 'formik'
import { postLoginAPI } from '../redux/APIS/API'
import toast from 'react-hot-toast'
import { reactLocalStorage } from 'reactjs-localstorage'
import { useDispatch } from 'react-redux'
import { UserActive } from '../redux/action/user-active'
import Image from 'next/image'
import logo from '../public/smi-logo.png'
import InstallAPPSMI from '../components/public-com/installApp';

function Login() {
   const [showpassword, setShowpassword] = useState(false)
   const [count, setCount] = useState(1)
   const router = useRouter()

   // const [showInstallPopup, setShowInstallPopup] = useState(false);

   // console.log(router.query, 'localquerynynext')



   const queryEmail = router?.query?.email

   const queryPassword = router?.query?.password



   const dispatch = useDispatch()

   useEffect(() => {

      const tokenVaild = reactLocalStorage.get('token', true)
      const user_role = reactLocalStorage.get('user_role')
      console.log(tokenVaild, 'username')
      if (tokenVaild == true) {
         router.push('/')
      } else if (user_role === 'tenant') {
         router.push('/tenant')
      } else {
         router.push('/tenants/list')
      }

   }, [])

   const validate = (values) => {
      const errors = {}

      if (!values.username) {
         errors.username = 'Please Enter Username'
      }

      if (!values.password) {
         errors.password = 'Please Enter Password'
      }

      return errors

   }

   const Loginfarmik = useFormik({
      initialValues: {
         username: queryEmail ? queryEmail : '',
         password: queryPassword ? queryPassword : ''
      },
      validate,
      onSubmit: async (value, { resetForm }) => {
         try {
            const respon = await postLoginAPI(value)
            console.log(respon, 'respon')
            reactLocalStorage.set('token', respon.data.data.token)

            reactLocalStorage.set('user_role', respon.data.data.user_role)

            let newDate = new Date()
            newDate.setDate(newDate.getDate() + 7)
            reactLocalStorage.set('date', newDate)
            dispatch(UserActive(respon.data.data))
            toast.success(respon.data.message)

            console.log(respon, 'respon')
            const Tenantuser = respon.data.data.user_role
            if (Tenantuser == 'tenant') {
               router.push('/tenant')
            } else {
               router.push('/tenants/list')
            }

         } catch (error) {
            resetForm()


            // console.log(error, 'responerror')

            toast.error('Your username or password is incorrect, please try again')


            setCount(() => count + 1)
            console.log(count)
            // toast.error(error.response.data.message)
            if (count == 3) {
               router.push('/auth/forget_password')
            }
            console.log(error)
         }
      }
   })



   return (
      <div className="Login page w-full h-screen min-h-screen overflow-x-hidden gradientLogin">
         <div className="w-[90%] sm:w-[50%] h-full min-h-screen mx-auto grid content-evenly">
            <div className="h-[40%] grid items-center ">
               <div className="logo-wrapper">
                  <div className="smi-logo">
                     <Image src={logo} />
                  </div>
               </div>
            </div>
            <div className='h-[60%] grid items-end pb-12'>
               <form className=" ">
                  <div className='md:px-[50px] md:bg-white py-5 px-8 bg-[#ffffffbf] md:shadow-[0_0_8px_3px_#a0a0a11f] rounded-[7px]'>
                     <div className="grid grid-cols-1 gap-[10px]">
                        <div className="grid grid-cols-1">
                           <label className="font-medium text-[12px] mb-[3px] text-[#262626] ">
                              Email / Username
                           </label>
                           <input
                              name="username"
                              id="username"
                              placeholder="Enter Your Username"
                              onChange={Loginfarmik.handleChange}
                              value={Loginfarmik.values.username}
                              className={` ${Loginfarmik.errors.username ? 'border-red-500 focus:border-red-500' : 'border-inputBorderColor'} 
                           font-medium text-[12px] w-full h-[35px] py-[5px] px-[10px] rounded-[5px] bg-[#FFF]
                           text-theme border-[1px] focus:border-theme focus:outline-none `}
                           />

                           {Loginfarmik.errors.username && (
                              <span className="text-red-500 font-medium text-[12px]">
                                 {Loginfarmik.errors.username}
                              </span>
                           )}
                        </div>

                        <div className="grid grid-cols-1 relative">
                           <label className="font-medium text-[12px] mb-[3px] text-[#262626]">
                              Password
                           </label>
                           <div className="relative">
                              <input
                                 name="password"
                                 id="password"
                                 type={showpassword ? 'text' : 'password'}
                                 // required
                                 onChange={Loginfarmik.handleChange}
                                 value={Loginfarmik.values.password}
                                 placeholder="Enter Your Password"
                                 className={` ${Loginfarmik.errors.password ? 'border-red-500 focus:border-red-500' : 'border-inputBorderColor'} 
                              font-medium text-[12px] w-full h-[35px] py-[5px] px-[10px] rounded-[5px] bg-[#FFF]  text-theme border-[1px] focus:border-theme focus:outline-none `} />
                              <span
                                 onClick={() => setShowpassword(!showpassword)}
                                 // title={showpassword? "Show Password": "Hide Password" }
                                 className="font-mono cursor-pointer text-[1.2em] bg-white pl-2 
                            absolute right-3 bottom-2"
                              >
                                 {showpassword ? <BsEye /> : <BsEyeSlash />}
                              </span>
                           </div>
                           {Loginfarmik.errors.password && (
                              <span className="text-red-500 font-medium text-[12px]">
                                 {Loginfarmik.errors.password}
                              </span>
                           )}
                        </div>

                        <div className="flex flex-col justify-between mb-3 ">
                           <Link href="/auth/forget_password">
                              <a className="font-medium text-theme text-[15px]">
                                 Forgot password ?
                              </a>
                           </Link>
                        </div>
                     </div>

                     <div className="grid grid-cols-1 w-full justify-items-center bg-buttonColor rounded-[5px] h-[40px] shadow-[0_0_30px_0_#0003] ">
                        <button onClick={Loginfarmik.handleSubmit}
                           className="font-medium text-blackC w-full h-[40px]">
                           Login
                        </button>
                     </div>

                     <div className="grid grid-cols-1 w-full justify-items-center mt-3">
                        <div className="flex flex-row sm:flex-row items-center justify-center sm:justify-between">
                           <Link href="/auth/register">
                              <a className="font-medium flex flex-row items-center gap-[2px] text-blackC text-[14px] tracking-[.025em]">
                                 Create New Account <IoChevronForwardOutline />
                              </a>
                           </Link>
                        </div>
                     </div>

                     <div className="grid grid-cols-1 w-full justify-items-center py-[20px] ">
                        <span>OR</span>
                     </div>


                     <div onClick={() => router.push('/auth/tenant_login')}
                        className="grid grid-cols-1 w-full justify-items-center bg-[#CCD9E6] rounded-[5px]
                         shadow-[0_0_30px_0_#0003] ">
                        <span className="font-medium text-blackC py-2 ">
                           Login as Tenant
                        </span>
                     </div>

                     <InstallAPPSMI showPopup={true} />

                  </div>
               </form>
            </div>
         </div>

      </div>
   )
}

export default Login
