import React from 'react'
import { useRouter } from 'next/router'
import AlignContractor from '../../components/projects/aligncontractor'
import NavigationButton from '../../components/tenants/details/navigation_button'
import SubHeader from '../../components/public-com/header'



export default function aligncontractor() {

    // eslint-disable-next-line react-hooks/rules-of-hooks
    const router = useRouter()




    function data() {
        // router.push('/projects/details')
        router.back()
    }

    return (
        <div>
            {/* <header className="z-50 bg-[#fff] pt-2  shadow-[1px_5px_13px_2px_#0000000d] sticky top-0 overflow-hidden"> */}
            <SubHeader
                Subtitle={'Request New Quote'}
                GoBack={true}
            />
            {/* </header> */}
            <div>
                <AlignContractor />
            </div>

            <NavigationButton
                BtnSecond={"Cancel"}
                BgcolorCancle={'bg-[#CCD9E6] text-[#262626]'}
                SecondOnClick={data}
            />
        </div>
    )
}
