import { useRouter } from 'next/router'
import React from 'react'
import AlignTenant from '../../components/projects/alignTenant'
import NavigationButton from '../../components/tenants/details/navigation_button'
import SubHeader from '../../components/public-com/header'

export default function tenants() {

    // eslint-disable-next-line react-hooks/rules-of-hooks
    const router = useRouter()

    function data() {
        // router.push('/projects/details')
        // alert("hello wolrd")
        router.back()
    }


    return (
        <AlignTenant />
    )
}
