
export const deletePhoto=async()=>{
 return axios.post
}