import React, { Fragment } from 'react'
import SubHeader from '../../components/public-com/header'
// import events from '../../components/schedule/events_data'
import FullCalendar from '@fullcalendar/react'
import interactionPlugin from '@fullcalendar/interaction'
import timeGridPlugin from '@fullcalendar/timegrid'
import dayGridPlugin from '@fullcalendar/daygrid'
// import AddNew from '../../components/tenants/add_user_button';
// import BottomNavigation from '../../components/public-com/bottom_navigation';
// import customViewPlugin from '../../components/schedule/custom-view';
import { useRef, useEffect, useState } from 'react'
import AddNew from '../../components/tenants/add_user_button'
import BottomNavigation from '../../components/public-com/bottom_navigation'
import { calendarAPI } from '../../redux/APIS/API'
// import CustomDropDown from '../../components/schedule/CustomDropDown'
import { useRouter } from 'next/router'
import { IoListOutline } from "react-icons/io5";
import { format } from 'date-fns'
import { reactLocalStorage } from "reactjs-localstorage";


// import { Popconfirm, message } from 'antd'

// import { data } from 'autoprefixer'

const Calendar = () => {
   const calendarRef = useRef()
   const datee = new Date()

   const [events, setEvents] = useState()
   const [data, setData] = useState([])

   // console.log(data);

   const [rows, setRows] = useState(1)

   console.log(events, 'events data')
   const [complateSche, setComplateSche] = useState('0')

   const router = useRouter();

   const Manager = reactLocalStorage.get('user_role')



   useEffect(() => {
      if (events) {
         const NewData = events.map(function (item) {
            const newArry = item.start.split(' ')
            const complate = item.schedule_complete
            setComplateSche(complate)
            return {
               title: item.title,
               date: newArry[0],
               className: item.schedule_complete === 1 ? 'isComplated' : 'isNotComplated',
            }
         })
         setData(NewData)
      }
   }, [events])

   const [showBy, setShowBy] = useState('dayGridMonth')

   const [date, setDate] = useState(datee.getMonth())
   //console.log(date)
   //console.log(dates)

   const [startDate, setStartDate] = useState()
   const [endDate, setEndDate] = useState()

   //create state for current month
   //put dates in state after event
   //create useffect and loop over dates from array to check if current month matches from the month of dates, if not matches then break loop
   //

   async function getDates() {
      try {
         const response = await calendarAPI({
            start_date: startDate,
            end_date: endDate,
            current_date: format(
               new Date(),
               'dd-MM-yyyy'
            )
         })
         console.log(response.data)
         setEvents(response.data.calendars)
      } catch (error) {
         console.log(error)
      }
   }

   useEffect(() => {
      getDates()
   }, [startDate, endDate])

   // console.log(complateSche, 'this is stutas')

   return (
      <div>
         {/* <header className="z-50 bg-[#fff] pt-2 shadow-[0px_1px_12px_3px_#0000000d] overflow-scroll"> */}
         <SubHeader title={'Schedule'} backUrl={'/schedule/list'} />
         {/* </header> */}

         <div className="my-[22px]">
            <div className='w-full flex items-center gap-2 justify-end mb-[22px] pr-3' onClick={() => router.push('/schedule/list')}>
               <IoListOutline className='h-[20px] w-[20px]' />
               <h1 className=" font-normal text-[#262626] cursor-pointer text-center text-[16px] ">Grid View</h1>
            </div>


            <FullCalendar
               className="text-xs leading-3"
               ref={calendarRef}
               headerToolbar={{
                  start: 'prev next title',
                  end: 'dayGridMonth dayGridWeek dayGridDay'
               }}
               plugins={[dayGridPlugin]}
               views={['dayGridMonth', 'dayGridWeek', 'dayGridDay']}
               // views={view}
               // events={events}
               // dayHeaderDidMount={(arg) => {
               //    console.log(arg, 'dayHeaderDidMount')
               // }}

               dayCellDidMount={(arg) => {
                  // console.log(arg.view.type)
                  if (arg.view.type === "dayGridDay") {
                     setRows(100)
                  } else {
                     setRows(1)
                  }

               }}
               datesSet={(arg) => {
                  setStartDate(arg.startStr.slice(0, 10))
                  setEndDate(arg.endStr.slice(0, 10))
               }}
               events={data}
               dayMaxEvents={rows}
               moreLinkContent={'see more...'}
               eventBackgroundColor={'#0000'}
               eventColor={'#0000'}
            />
         </div>
         {Manager == 'app_manager' ? null :
            <AddNew href={'/schedule/form'} bottom={'bottom-20'} />}

         <BottomNavigation />
      </div>
   )
}

export default Calendar
