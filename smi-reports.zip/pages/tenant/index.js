import React from 'react'
import { useEffect, useState } from 'react'
import { reactLocalStorage } from 'reactjs-localstorage'
import SubHeader from '../../components/public-com/header'
import { useDispatch, useSelector } from "react-redux";
import { getTenantDetail } from '../../redux/action/tenants-detail';
import { useRouter } from 'next/router';
import BottomNavigation from '../../components/public-com/bottom_navigation';
import {
    IoListOutline,
    IoList,
    IoGridOutline,
    IoGrid
} from 'react-icons/io5'
import { getSendFiles } from '../../redux/APIS/API';
import PreViewPDF from '../../components/tenants/details/PreViewPDF';
import TanantsLightbox from '../../components/tenants/details/lightbox';
import PdfThumbnail from '../../components/public-com/pdfThumbnail';


function Index() {

    const userID = reactLocalStorage.get('default_post_id')
    const [imageSrc, setImageSrc] = useState(true)
    const [pdfUrl, setPdfUrl] = useState('')
    const [showPDFPreview, setShowPDFPreview] = useState(false)
    const [openLightBox, setOpenLightBox] = useState(false)
    const [layoutOption, setLayoutOption] = useState(false)
    const [sharePhotos, setSharePhotos] = useState([])




    const dispatch = useDispatch();
    const router = useRouter();

    const item = useSelector(
        (state) => state.tenantsDetails.tenantsDetails?.data
    )

    async function GetSendFiles(ID) {

        let data = { 'tenant_id': ID }
        const res = await getSendFiles(data)
        console.log(res?.data?.data, 'resdata')
        setSharePhotos(res?.data?.data)

    }


    useEffect(() => {

        if (userID) {
            dispatch(getTenantDetail(userID))
            GetSendFiles(userID)
        }

    }, [userID])


    const Boxdata = [
        {
            name: 'Project Request',
            discription: 'Send a service, maintenance or inspection request to your property manager',
            link: '/tenant/project_request',
        },
        {
            name: 'Send A Message',
            discription: 'Send a message to your property manager with your questions, comments or concerns',
            link: '/tenant/message',
        }
    ]

    const OpenLight = (img) => {
        setImageSrc(img)
        setOpenLightBox(true)
    }

    function onClickPreview(value) {
        setPdfUrl(value)
        setShowPDFPreview(true)
    }


    return (
        <div>
            <SubHeader title={'Home'} />

            <div className="grid w-full py-4 px-4   mb-[75px]">

                <div className="flex w-full items-center"  >
                    <div className="w-[100%] grid">
                        <div className="grid items-center gap-2 mb-5  ">
                            <div className="flex items-center">
                                <h1 className="text-[16px] font-normal ">
                                    {item?.company_name}
                                </h1>
                            </div>
                            <div className='w-full '>
                                {item?.property?.length > 0 &&
                                    <span className="text-[11px] font-normal text-[#262626] font-sans border-set  ">
                                        {item?.property}
                                    </span>}
                            </div>
                        </div>


                        <span className='text-[12px] text-[#262626] mb-4 '>Choose an option to get started</span>
                        <div className="grid gap-y-6 gap-x-4 grid-cols-2 ">


                            {Boxdata.map((item, index) =>
                                <div
                                    key={index}
                                    onClick={() => router.push(item.link)}
                                    className='px-4 py-4 border-[1px] border-[#D9D9D9] rounded-[10px] bg-[#fff] ' >
                                    <h1 className="text-[13px] font-[400] font-sans text-[#262626]">
                                        <p className='text-[30px] text-[#262626] font-normal font-sans Oswald-font'>{item.name}</p>
                                        {item.discription}
                                    </h1>
                                </div>
                            )}
                        </div>

                        <div className="grid w-full py-4 px-2 ">
                            <div className="flex gap-2">
                                <div className="w-[100%]">
                                    <div className="flex justify-between items-center">
                                        <div className="">
                                            <span className="text-[20px] font-normal Oswald-font text-[#262626]">
                                                Shared Files
                                            </span>
                                        </div>

                                        <div className="flex w-[20%] gap-1 justify-end ">
                                            <div
                                                className=" p-[5px] "
                                                onClick={() => setLayoutOption(false)}
                                            >
                                                {layoutOption ? (
                                                    <IoListOutline className="text-lg cursor-pointer" />
                                                ) : (
                                                    <IoList className="text-lg cursor-pointer" />
                                                )}
                                            </div>

                                            <div
                                                className=" p-[5px] "
                                                onClick={() => setLayoutOption(true)}
                                            >
                                                {layoutOption ? (
                                                    <IoGrid className="text-lg cursor-pointer " />
                                                ) : (
                                                    <IoGridOutline className="text-lg cursor-pointer " />
                                                )}
                                            </div>
                                        </div>
                                    </div>

                                    <hr className="my-1 border-t-2" />

                                    <span className='text-[12px] text-[#262626]'>View files shared with you by your administrator</span>

                                    {/* <AddPhotoD clientName={'tenants'} /> */}




                                    {/* list view */}

                                    <div className={layoutOption ? 'hidden' : 'block'}>
                                        <div className="grid grid-cols-3 gap-3 mt-2 mb-[15px]">
                                            {sharePhotos?.map((item, index) => (
                                                <div key={index}>
                                                    <div
                                                        className="h-[100px] w-[100px] overflow-hidden shadow-sm rounded-md group relative bg-cover object-center object-fill "
                                                    >
                                                        {

                                                            item?.photo_src?.includes('png') ||
                                                                item?.photo_src?.includes('jpg') ||
                                                                item?.photo_src?.includes('jpeg') ?
                                                                < img src={
                                                                    item?.photo_src
                                                                } alt={'Photo'}
                                                                    onClick={() => OpenLight(item?.photo_src)}
                                                                    className='w-full object-cover  rounded-md object-center h-full'
                                                                />
                                                                :
                                                                <PdfThumbnail url={item?.photo_src}
                                                                    onClick={() => onClickPreview(item?.photo_src)} />
                                                        }
                                                    </div>

                                                    <h1 className="text-[10px] break-all font-normal text-[#262626] ">{item?.real_file_name.length > 0 ?
                                                        item?.real_file_name
                                                        : "--"}</h1>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    {/* grid view */}
                                    <div className={layoutOption ? 'block' : 'hidden'}>
                                        <div className="grid grid-cols-3 gap-2 ">
                                            {sharePhotos?.map((item, index) => (
                                                <div key={index}>
                                                    <div

                                                        className="h-[100px] w-[100px] overflow-hidden shadow-sm rounded-md group relative bg-cover object-center object-fill "
                                                    >
                                                        {

                                                            item?.photo_src?.includes('png') ||
                                                                item?.photo_src?.includes('jpg') ||
                                                                item?.photo_src?.includes('jpeg') ?
                                                                < img src={
                                                                    item?.photo_src
                                                                } alt={'Photo'}
                                                                    onClick={() => OpenLight(item?.photo_src)}
                                                                    className='w-full object-cover  rounded-md object-center h-full'
                                                                />
                                                                :
                                                                <PdfThumbnail url={item?.photo_src}
                                                                    onClick={() => onClickPreview(item?.photo_src)} />
                                                        }
                                                    </div>


                                                    <h1 className="text-[10px]  break-all  font-normal text-[#262626] ">{item?.real_file_name.length > 0 ?
                                                        item?.real_file_name
                                                        : "--"}</h1>

                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>


                {showPDFPreview &&
                    <PreViewPDF
                        datashow={showPDFPreview}
                        onClick={() => setShowPDFPreview(false)}
                        PDFURL={pdfUrl}
                    />
                }

                {openLightBox && (
                    <TanantsLightbox
                        // data={imageDis}
                        src={imageSrc}
                        datashow={openLightBox ? 'block' : 'hidden'}
                        close={() => setOpenLightBox(false)}
                    // photo_detail={imageDis}
                    />
                )
                }



            </div>

            <BottomNavigation />
        </div>
    )
}

export default Index