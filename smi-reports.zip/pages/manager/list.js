import AddNew from "../../components/tenants/add_user_button";
import BottomNavigation from "../../components/public-com/bottom_navigation";
import SubHeader from "../../components/public-com/header";
import ListItem from "../../components/tenants/list";
import { useSelector, useDispatch } from "react-redux";
import DefultScreen from "../../components/public-com/DefultScreen";
import Sort from "../../components/manager/sort";
import List from "../../components/manager/list";
import { reactLocalStorage } from "reactjs-localstorage";



function ManegerList() {

    // const dispatch = useDispatch();

    // const item = useSelector((state) => state.tenants.tenants?.any_record_created)

    // const item = useSelector((state) => state.projectsRequest.projectsRequest.total_projects)

    // console.log(item, 'tenants')


    const Manager = reactLocalStorage.get('user_role')
    let item = '0';

    return (
        <div className="">
            <SubHeader title={"Manager List"} />


            {item === '0' ? <><Sort /><List />
                {Manager === 'app_manager' ? null :
                    <AddNew href={"/manager/form"} />} </> :
                <DefultScreen
                    Title={'New project requests from Tenants will automatically show up here'}
                    SecondTitle={'No Requests'} />
            }

            <BottomNavigation />
        </div >
    )
}

export default ManegerList;