import React from 'react'
import SubHeader from '../../../components/public-com/header'
import SecureNotesDetailComponent from '../../../components/security_info/secure_note/details'
import NavigationButton from '../../../components/tenants/details/navigation_button'

function SecureNotesDetail() {
    return (
        <div>

            <SubHeader title={"Item Details "} backUrl={'/security_info/secure_notes'} />

            <SecureNotesDetailComponent />

            <NavigationButton
                BtnFirst={"Edit"}
                BtnFirstOnclick={() => {
                    console.log("Edit Button ")
                }}
                BtnSecond={"Delete"}
                SecondOnClick={console.log("delete Button ")} />


        </div>
    )
}

export default SecureNotesDetail