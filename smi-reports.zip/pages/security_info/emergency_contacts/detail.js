import React from 'react'
import SubHeader from '../../../components/public-com/header'
import EmergencyContactsDetailComponent from '../../../components/security_info/emergency_contacts/details'
import NavigationButton from '../../../components/tenants/details/navigation_button'

function EmergencyContactsDetail() {
    return (
        <div>

            <SubHeader title={"Contact Details"} backUrl={'/security_info/emergency_contacts'} />

            <EmergencyContactsDetailComponent />

            <NavigationButton
                BtnFirst={"Edit"}
                BtnFirstOnclick={() => {
                    console.log("Edit Button ")
                }}
                BtnSecond={"Delete"}
                SecondOnClick={console.log("delete Button ")} />


        </div>
    )
}

export default EmergencyContactsDetail