import { useState } from "react";
import SupportDetailComponent from '../../components/support/details'
import DeletePopup from '../../components/support/deletePopup'
import NavigationButton from '../../components/tenants/details/navigation_button'
import SubHeader from '../../components/public-com/header'
import { useRouter } from 'next/router';
import { useSelector } from "react-redux";
import { reactLocalStorage } from "reactjs-localstorage";
import CancelComponent from "../../components/public-com/cancelComponent";




function SupportDetail() {

    const [showPopup, setShowPopup] = useState(false);

    // const dispatch = useDispatch()

    const router = useRouter();

    // const userID = useSelector((state) => state?.singleSupport?.singleSupport?.data?.data.ID)

    // console.log(userID, 'userID');


    const Manager = reactLocalStorage.get('user_role')

    return (
        <div>
            {/* <header className='z-50 bg-[#fff] pt-2 shadow-[1px_5px_13px_2px_#0000000d] overflow-scroll'> */}
            <SubHeader title={'Support Details'} backUrl={'/support/list'} />
            {/* </header> */}

            <SupportDetailComponent />

            <DeletePopup
                datashow={showPopup ? "block" : "hidden"}
                onClicked={() => setShowPopup(false)}
            />

            {Manager === 'app_manager' ?
                <CancelComponent /> :
                <NavigationButton
                    BtnFirst={"Edit"}
                    BtnFirstOnclick={() => router.push(`/support/form?edit=true`)}
                    BtnSecond={"Delete"}
                    SecondOnClick={() => setShowPopup(true)}
                />}

        </div>
    )
}

export default SupportDetail