import React from 'react'

const alreadyCreated = () => {
   return (
      <div className="font-bold text-xl text-center px-4 py-4  h-screen flex ">
         <div className="mt-auto mb-auto">
            <h1>You have already submitted response for the bid.</h1>
         </div>
      </div>
   )
}

export default alreadyCreated
