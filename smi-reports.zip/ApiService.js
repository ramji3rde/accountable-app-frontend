import axios from 'axios';
import { reactLocalStorage } from 'reactjs-localstorage'
import toast from 'react-hot-toast'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react';


// import {
//   token,
// } from './utils';
const AxiosInstance = axios.create({
  headers: {
    'Content-Type': 'application/json',
    // 'Content-Type': 'multipart/form-data',
  },

});



function userLogout(ErrorCode) {
  const router = useRouter()
  console.log(ErrorCode, 'ErrorCode ErrorCode')
  reactLocalStorage.clear()
  toast.success('Log Out SuccessFully')
  router.push('/')
  // if (ErrorCode == '403' || ErrorCode == '404') {

  //   Logout()
  // }
}


// function Logout() {
//   const router = useRouter()
//   reactLocalStorage.clear()
//   toast.success('Log Out SuccessFully')
//   router.push('/')
// }




AxiosInstance.interceptors.request.use(
  async config => {
    return config;
  },
  error => {
    return Promise.reject(error);
  },
);
AxiosInstance.interceptors.response.use(

  // try {
  //   res => {
  //     return res;
  //   }
  // }catch{

  // }
  res => {
    return res;
  },
  async err => {
    return (
      console.log(err, 'AxiosInstance AxiosInstance'),
      console.log(err?.response?.status, 'err AxiosInstance'),
      reactLocalStorage.clear(),
      userLogout(err?.response?.status),
      Promise.reject(err)
    )

  },
);

export default AxiosInstance;
