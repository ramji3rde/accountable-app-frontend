import { reactLocalStorage } from "reactjs-localstorage"

export const token = (data = null) => {
    try {
        if (data) {

            return ({

                headers: {
                    // 'Access-Control-Allow-Origin': '*',
                    'Authorization': `Bearer ${data}`
                }
            })
        } else {
            const token = reactLocalStorage.get("token", false)
            return ({
                headers: {
                    // 'Access-Control-Allow-Origin': '*',
                    'Authorization': `Bearer ${token}`
                }
            })

        }


    } catch (error) {

    }

}