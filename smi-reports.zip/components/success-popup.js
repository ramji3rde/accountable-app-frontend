import React from "react";
import toast from 'react-hot-toast';
import { useRouter } from 'next/router';
import { BsFillCheckCircleFill } from 'react-icons/bs'




// function SuccessPopup(props) {


//     const dispatch = useDispatch()

//     const router = useRouter();


//     return (
//         <div className={props.datashow} >
               
//             <div style={{ transition: '.5s', }} className='DeletePopup h-screen bg-[#22222238]  w-full fixed z-[100] top-0 left-0 overflow-hidden'>

//                 <div className="">

//                     <div className="absolute w-[80%]  top-[30%] left-[10%] h-[165px] mx-auto bg-white rounded-[18px]">
//                         <div className="text-black text-center pt-10">
//                             <div className=' flex items-center justify-center text-[#4DE060] '>
//                                 <BsFillCheckCircleFill className='h-[43.33px] w-[43.33px] mb-4'  />
//                             </div>
//                             <p className="text-[16px] text-[#262626] font-normal px-4 py-3">
//                             Your request was successfully sent !</p>

//                             <div className="flex justify-center">

//                             </div>
//                         </div>
//                     </div>

//                 </div>

//             </div>
//         </div>
        
//     )

// }

// export default SuccessPopup;

// toast.custom((t) => (
//     <div
//     className={`${
//         t.visible ? 'animate-enter' : 'animate-leave'
//     } max-w-md w-full bg-white shadow-lg rounded-lg pointer-events-auto flex ring-1 ring-black ring-opacity-5`}
//     >
//         { console.log(t ,'custom popup')}
//       <div className="flex-1 w-0 p-4">
//         <div className="flex items-start">
//           <div className="flex-shrink-0 pt-0.5">
//             <img
//               className="h-10 w-10 rounded-full"
//               src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixqx=6GHAjsWpt9&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2.2&w=160&h=160&q=80"
//               alt=""
//             />
//           </div>
//           <div className="ml-3 flex-1">
//             <p className="text-sm font-medium text-gray-900">
//               Emilia Gates
//             </p>
//             <p className="mt-1 text-sm text-gray-500">
//               Sure! 8:30pm works great!
//             </p>
//           </div>
//         </div>
//       </div>
//       <div className="flex border-l border-gray-200">
//         <button
//           onClick={() => toast.dismiss(t.id)}
//           className="w-full border border-transparent rounded-none rounded-r-lg p-4 flex items-center justify-center text-sm font-medium text-indigo-600 hover:text-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
//         >
//           Close
//         </button>
//       </div>
//     </div>
//   ))