import { useRouter } from "next/router";
import Loader from "../../public-com/loader";
import { IoCall } from "react-icons/io5";



function ListItem() {

    // const dispatch = useDispatch();

    const router = useRouter();

    // const clients = useSelector((state) => state.tenants.tenants?.data)
    // // console.log(clients);

    const loading = false

    const data = [
        {
            name: "Deputy Daniel Johnson",
            status: "Fire Department",
        },
        {
            name: "Chief. Lucas Davis",
            status: "Police Department",
        },
        {
            name: "Hapeville EMS",
            status: "Emergency Medical Services",
        },
        {
            name: "Sarah Johnson",
            status: "Campus Security",
        }
    ]



    return (
        <div className="list">


            {loading ?
                <Loader /> :
                <div className="body ">
                    <div className="ListDetails mb-20 bg-[#f4f5f7] pb-[70px] ">
                        {data?.map((item, index) =>
                            <div key={index} className='mb-[5px] ml-[12px] '>
                                <div className='flex  w-[100%] h-[66px] gap-[3px] items-center  rounded-l-lg bg-[#FFFFFF] px-4 min-w-fit'>

                                    <div className="w-[100%] " >

                                        <div className="w-full "
                                            onClick={() => router.push('/security_info/emergency_contacts/detail')}
                                        >
                                            <div className="flex overflow-hidden ">
                                                <h1 className="text-[16px] font-[400] capitalize oneLineTextlimit text-[#262626] not-italic ">
                                                    {item.name}
                                                </h1>

                                            </div>
                                            <div className="flex opacity-80 gap-[10px] items-center  mt-1">
                                                {item.status && <span className={`${item.status ? ' border-set' : ''} not-italic text-[11px]  font-sans
                                                 text-[#000] font-normal capitalize`}>{item.status}</span>}
                                                {item.email && <span className={` not-italic text-[11px]  font-sans
                                                 text-[#000] font-normal capitalize`}>{item.email}</span>}
                                            </div>

                                            {/* <div className="flex opacity-80 gap-[10px] items-center  mt-1">
                                                
                                            </div> */}
                                        </div>
                                    </div>

                                    <div className="w-[20%]  flex justify-between items-center">
                                        <IoCall className="h-[23.16px] w-[23.65px]" />
                                        {/* <div>
                                            {item?.company_flag === "true" && <IoFlagSharp className="text-lg  text-red-500" />}
                                        </div>
                                        <Link href={'tel:' + item.primary_phone}>
                                            <a>
                                                <IoCall className="h-[23.16px] w-[23.65px]" />
                                            </a>
                                        </Link> */}
                                    </div>
                                </div>
                                <hr />
                            </div>
                        )}

                    </div>
                    {data?.length == 0 && (
                        <div className='absolute w-full h-full top-0 left-0 bg-[#f8fafc] z-[-99]'>
                            <div className='w-full h-full grid justify-center items-center z-[-99]'>
                                <div className='text-center'>
                                    <div>
                                        <span>no data</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                </div>
            }
        </div>
    )
}

export default ListItem;

