# SMI Reports PWA (Progressive Web Application)
(Service, Maintenance and Inspection)

###  Commercial Property Management System

💡  A smart system to manage and communicate with your commercial property's Tenants, Contractors, Vendors and Support Personnel!

🛠  Automate your workflow by creating projects that you can easily send to contractors to quickly receive multiple project quotes and estimates right in the app.

📆 Stay on schedule and keep track your daily tasks around your project. 

✅ Manage employees and helping hands around your property with reports to view the history of completed tasks, projects reported incidents and more.
